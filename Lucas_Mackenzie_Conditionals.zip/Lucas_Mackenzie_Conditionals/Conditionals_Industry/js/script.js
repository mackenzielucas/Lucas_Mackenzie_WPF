/**
 * Created by MAC on 9/18/14.
 */
/*
Mackenzie Lucas
September 18, 2014
Conditionals Assignment
 */

alert("Testing?");